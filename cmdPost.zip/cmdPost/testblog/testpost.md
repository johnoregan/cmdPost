---
title: Test Post
author: Your Name
date: 2016/12/15 20:35
status: publish
comments: open
pingbacks: open
sticky: 0
format: standard
categories: Uncategorized
tags: blogging client, command post, test post
---

Only text before the `<!-- more -->` tag will be displayed on the
front page of your blog...

<!--more more &raquo;-->

...and everything after will be displayed on the page for the blog post. :smiley:
